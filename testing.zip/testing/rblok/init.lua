minetest.register_node("rblok:Tancarpet4", {
description = "tan carpet4",
tiles = {"fabric_dark_cyan.jpg","tan2.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:Tancarpet3", {
description = "tan carpet3",
tiles = {"fabric_dark_orange.jpg","tan2.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("rblok:Tancarpet2", {
description = "tan carpet2",
tiles = {"fabric_darkgrey.jpg","tan2.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:Tanwood2", {
description = "tan wood2",
tiles = {"woodtopb.png","tan2.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:Tantile2", {
description = "tan tile2",
tiles = {"tile_white.png","tan2.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("rblok:flcpdrgrey", {
description = "flcpdrgrey",
tiles = {"fabric_darkgrey.jpg","floorwood1a.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:flcpcyan", {
description = "flcpcyan",
tiles = {"fabric_dark_cyan.jpg","floorwood1a.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:flcporange", {
description = "flcporange",
tiles = {"fabric_dark_orange.jpg","floorwood1a.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:flcpgrey", {
description = "flcargrey",
tiles = {"fabric_grey.png","floorwood1a.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:floorwood1a", {
description = "floorwood1a",
tiles = {"floorwood1a.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:floorwood2b", {
description = "floorwood2b",
tiles = {"floorwood2a.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:floorwood1", {
description = "floorwood1",
tiles = {"floorwood1.jpg", "technic_blast_resistant_concrete_block1.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:floorwood2", {
description = "floorwood2",
tiles = {"floorwood2.jpg", "technic_blast_resistant_concrete_block1.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:techConcreteGrey", {
description = "techConcreteGrey",
tiles = {"fabric_grey.png", "technic_blast_resistant_concrete_block1.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:techConcreteDGrey", {
description = "techConcreteGrey",
tiles = {"fabric_darkgrey.jpg", "technic_blast_resistant_concrete_block1.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("rblok:drywallblueGrey2", {
description = "dry wall blueGrey1",
tiles = {"blueGrey1.png", "baked_clay_white.png" },
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:drywallcolorTest", {
description = "dry wall colorTest",
tiles = {"colorTest.png", "baked_clay_white.png" },
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:drywallcolorTest2", {
description = "dry wall colorTest2",
tiles = {"colorTest2.png", "baked_clay_white.png" },
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:drywalltan2", {
description = "dry wall tan2",
tiles = {"tan2.png", "baked_clay_white.png" },
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:drywallbrown3", {
description = "dry wall brown3",
tiles = {"brown3.png", "baked_clay_white.png" },
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:drywalltan1", {
description = "dry wall tan1",
tiles = {"tan1.png", "baked_clay_white.png" },
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:tan2", {
description = "block wall tan2",
tiles = {"tan2.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:brown3", {
description = "block wall brown3",
tiles = {"brown3.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:tan1", {
description = "block wall tan1",
tiles = {"tan1.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:bluegrey", {
description = "block wall bluegrey",
tiles = {"blueGrey.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:blueGrey1", {
description = "block wall blueGrey1",
tiles = {"blueGrey1.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:brown1", {
description = "block wall rbrown1",
tiles = {"colorTest.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:brown2", {
description = "block wall rbrown2",
tiles = {"colorTest2.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:darkgrey1", {
description = "block wall darkgrey1",
tiles = {"dark_grey.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:water_feature", {
   description = "Water Feature",
   drawtype = "nodebox",
   tiles = {
          {
             name = "default_water_flowing_animated.png",
             animation = {
                type = "vertical_frames",
                aspect_w = 16,
                aspect_h = 16,
                length = 0.8,
             },
          },
       },
       special_tiles = {
          -- New-style water source material (mostly unused)
          {
             name = "default_water_flowing_animated.png",
             animation = {
                type = "vertical_frames",
                aspect_w = 16,
                aspect_h = 16,
                length = 0.8,
             },
             backface_culling = false,
          },
       },
       alpha = 160,
    inventory_image = "default_water_flowing_animated.png",
   wield_image = "default_water_flowing_animated.png",
   paramtype = "light",
    light_source = 5,
   paramtype2 = "facedir",
   legacy_facedir_simple = true,
   is_ground_content = false,
   node_box = {
      type = "fixed",
      fixed = {
         {-0.5, -0.5, 0.4375, 0.5, 0.5, 0.5},
      },
   },
   selection_box = {
      type = "fixed",
      fixed = {
         {-0.5, -0.5, 0.4375, 0.5, 0.5, 0.5},
      },
   },
   groups = {cracky=3, stone=2},
   sounds = default.node_sound_stone_defaults(),
})




--node definition

minetest.register_node("rblok:crate1", {
description = "crate1 ",
tiles = {"crate1.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
selection_box = {
	 type = "fixed",
	 fixed = {-.5, -.5, -.5, .5, .5, .5},
	 },
collision_box = {
	 type = "fixed",
	 fixed = {-.5, -.5, -.5, .5, .5, .5},
	 },
})

minetest.register_node("rblok:stonepath3", {
description = "stonepath3 ",
tiles = {"stonepath3.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
selection_box = {
	 type = "fixed",
	 fixed = {-.5, -.5, -.5, .5, .5, .5},
	 },
collision_box = {
	 type = "fixed",
	 fixed = {-.5, -.5, -.5, .5, .5, .5},
	 },
})

minetest.register_node("rblok:metalTile", {
description = "metalTile ",
tiles = {"metalTile.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
selection_box = {
	 type = "fixed",
	 fixed = {-.5, -.5, -.5, .5, .5, .5},
	 },
collision_box = {
	 type = "fixed",
	 fixed = {-.5, -.5, -.5, .5, .5, .5},
	 },
})

minetest.register_node("rblok:tantiles", {
description = "tantiles ",
tiles = {"tantiles.png" },
--walkable=false,
paramtype = "light",
--paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
selection_box = {
	 type = "fixed",
	 fixed = {-.5, -.5, -.5, .5, .5, .5},
	 },
collision_box = {
	 type = "fixed",
	 fixed = {-.5, -.5, -.5, .5, .5, .5},
	 },
})

minetest.register_node("rblok:FloorTexture", {
description = "FloorTexture ",
tiles = {"FloorTexture.jpg" },
--walkable=false,
paramtype = "light",
--paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
selection_box = {
	 type = "fixed",
	 fixed = {-.5, -.5, -.5, .5, .5, .5},
	 },
collision_box = {
	 type = "fixed",
	 fixed = {-.5, -.5, -.5, .5, .5, .5},
	 },
})

minetest.register_node("rblok:stonepath2", {
description = "stonepath2 ",
tiles = {"stonepath2.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
selection_box = {
	 type = "fixed",
	 fixed = {-.5, -.5, -.5, .5, .5, .5},
	 },
collision_box = {
	 type = "fixed",
	 fixed = {-.5, -.5, -.5, .5, .5, .5},
	 },
})

minetest.register_node("rblok:stonepath1", {
description = "stonepath1 ",
tiles = {"stonepath1.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
selection_box = {
	 type = "fixed",
	 fixed = {-.5, -.5, -.5, .5, .5, .5},
	 },
collision_box = {
	 type = "fixed",
	 fixed = {-.5, -.5, -.5, .5, .5, .5},
	 },
})

minetest.register_node("rblok:cherry_leaves", {
description = "cherry_leaves ",
tiles = {"cherry_leaves.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
selection_box = {
	 type = "fixed",
	 fixed = {-.5, -.5, -.5, .5, .5, .5},
	 },
collision_box = {
	 type = "fixed",
	 fixed = {-.5, -.5, -.5, .5, .5, .5},
	 },
})

minetest.register_node("rblok:rblokpine", {
description = "rblokpine ",
tiles = {"rblokpine.png" },
drawtype = plantlike,
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
selection_box = {
	 type = "fixed",
	 fixed = {-.5, -.5, -.5, .5, .5, .5},
	 },
collision_box = {
	 type = "fixed",
	 fixed = {-.5, -.5, -.5, .5, .5, .5},
	 },
})

local jp_cbox = {
	type = "fixed",
	fixed = {-0.5, -0.5, 0, 0.5, 0.5, 0.0625},
}

local p_cbox = {
	type = "fixed",
	fixed = {
		{ -0.5, -0.5, 0.4375, 0.5, 0.5, 0.5 }
	}
}


 --local lux_wood = {name = "homedecor_generic_wood_luxury.png^ color = 0xff643f23" }
local lux_wood      = { name = "homedecor_generic_wood_luxury.png", color = 0xff643f23 }

minetest.register_node("rblok:jpdoor", {
 description = "jpdoor",
 drawtype = "mesh",
 mesh = "jpDoorTest1.obj",
 tiles = {--"wool_white.jpg","woodtopb.png",
 "homedecor_japanese_paper.png",lux_wood,
 --"homedecor_japanese_paper.png","woodtopb.png",
 },
 groups = {choppy=2, dig_immediate=2},
 paramtype = "light",
 paramtype2 = "facedir",
 	selection_box = p_cbox,
collision_box = p_cbox,
expand = { top = "placeholder" },
on_rightclick = function(pos, node, clicker, itemstack, pointed_thing)
	minetest.set_node(pos, {name = "rblok:jpdooropen", param2 = node.param2})
	return itemstack
end
		})

		minetest.register_node("rblok:jpdooropen", {
		 description = "jpdooropen",
		 drawtype = "mesh",
		 mesh = "jpopendooropen.obj",
		 tiles = {--"wool_white.jpg","woodtopb.png",
		 --"homedecor_japanese_paper.png",lux_wood,
		 lux_wood,"homedecor_japanese_paper.png",
		 --"homedecor_japanese_paper.png","woodtopb.png",
		 },
		groups = { snappy = 3, not_in_creative_inventory = 1 },
		 paramtype = "light",
		 paramtype2 = "facedir",
		 	selection_box = p_cbox,
		collision_box = p_cbox,
		expand = { top = "placeholder" },
		on_rightclick = function(pos, node, clicker, itemstack, pointed_thing)
			minetest.set_node(pos, {name = "rblok:jpdoor", param2 = node.param2})
			return itemstack
		end,
		drop = "rblok:jpdoor",
				})

		minetest.register_node("rblok:jpdoorclear", {
		 description = "jpdoorclear",
		 drawtype = "mesh",
		 mesh = "jpDoorTest1.obj",
		 tiles = {--"wool_white.jpg","woodtopb.png",
		 "default_glass_detail.png",lux_wood,
		 --"homedecor_japanese_paper.png","woodtopb.png",
		 },
		 groups = {choppy=2, dig_immediate=2},
		 paramtype = "light",
		 paramtype2 = "facedir",
		 	selection_box = p_cbox,
		collision_box = p_cbox,
				})

				minetest.register_node("rblok:jpdoorbottom", {
				 description = "jpdoorbottom",
				 drawtype = "mesh",
				 mesh = "bottomPanel.obj",
				 tiles = {--"wool_white.jpg","woodtopb.png",
				 lux_wood,
				 --"homedecor_japanese_paper.png","woodtopb.png",
				 },
				 groups = {choppy=2, dig_immediate=2},
				 paramtype = "light",
				 paramtype2 = "facedir",
				 	selection_box = p_cbox,
				collision_box = p_cbox,
						})

						minetest.register_node("rblok:jpdoortop", {
						 description = "jpdoortop",
						 drawtype = "mesh",
						 mesh = "toppanel.obj",
						 tiles = {--"wool_white.jpg","woodtopb.png",
						 lux_wood,
						 --"homedecor_japanese_paper.png","woodtopb.png",
						 },
						 groups = {choppy=2, dig_immediate=2},
						 paramtype = "light",
						 paramtype2 = "facedir",
						 	selection_box = p_cbox,
						collision_box = p_cbox,
								})

								minetest.register_node("rblok:jpdoortoppanel", {
								 description = "jpdoortop",
								 drawtype = "mesh",
								 mesh = "toppanel.obj",
								 tiles = {
								 "homedecor_japanese_paper.png",lux_wood,

								 },
								 groups = {choppy=2, dig_immediate=2},
								 paramtype = "light",
								 paramtype2 = "facedir",
								 	selection_box = p_cbox,
								collision_box = p_cbox,
										})

										minetest.register_node("rblok:jpdoortopclear", {
										 description = "jpdoortopclear",
										 drawtype = "mesh",
										 mesh = "toppanel.obj",
										 tiles = {--"wool_white.jpg","woodtopb.png",
										 "default_glass_detail.png",lux_wood,
										 --"homedecor_japanese_paper.png","woodtopb.png",
										 },
										 groups = {choppy=2, dig_immediate=2},
										 paramtype = "light",
										 paramtype2 = "facedir",
										 	selection_box = p_cbox,
										collision_box = p_cbox,
												})

												minetest.register_node("rblok:jpdoormiddel", {
												 description = "jpdoormiddel",
												 drawtype = "mesh",
												 mesh = "panelmiddle.obj",
												 tiles = {--"wool_white.jpg","woodtopb.png",
												 "homedecor_japanese_paper.png",lux_wood,
												-- "default_glass_detail.png",lux_wood,
												 --"homedecor_japanese_paper.png","woodtopb.png",
												 },
												 groups = {choppy=2, dig_immediate=2},
												 paramtype = "light",
												 paramtype2 = "facedir",
												 	selection_box = p_cbox,
												collision_box = p_cbox,
														})

														minetest.register_node("rblok:jpdoormiddelclear", {
														 description = "jpdoormiddelclear",
														 drawtype = "mesh",
														 mesh = "panelmiddle.obj",
														 tiles = {--"wool_white.jpg","woodtopb.png",
														 --"homedecor_japanese_paper.png",lux_wood,
														"default_glass_detail.png",lux_wood,
														 --"homedecor_japanese_paper.png","woodtopb.png",
														 },
														 groups = {choppy=2, dig_immediate=2},
														 paramtype = "light",
														 paramtype2 = "facedir",
														 	selection_box = p_cbox,
														collision_box = p_cbox,
																})

																minetest.register_node("rblok:rblok_wall_japanese_bottom", {
																 description = "rblok_wall_japanese_bottom",
																 drawtype = "mesh",
																 mesh = "rblok_wall_japanese_bottom.obj",
																 tiles = {
															 		lux_wood,
															 		--"homedecor_japanese_paper.png"
															 	},
															 	paramtype = "light",
															 	paramtype2 = "facedir",
															 	groups = {snappy=3},
															 	selection_box = jp_cbox,
															 	collision_box = jp_cbox,
															 	sounds = default.node_sound_wood_defaults(),
																		})

																		minetest.register_node("rblok:rblok_wall_japanese_middle", {
																		 description = "rblok_wall_japanese_middle",
																		 drawtype = "mesh",
																		 mesh = "rblok_wall_japanese_middle.obj",
																		 tiles = {
																	 		lux_wood,
																	 		--"homedecor_japanese_paper.png"
																			"default_glass_detail.png"
																	 	},
																	 	paramtype = "light",
																	 	paramtype2 = "facedir",
																	 	groups = {snappy=3},
																	 	selection_box = jp_cbox,
																	 	collision_box = jp_cbox,
																	 	sounds = default.node_sound_wood_defaults(),
																				})

	minetest.register_node("rblok:rblok_wall_japanese_top", {
	description = "rblok_wall_japanese_top",
	drawtype = "mesh",
  mesh = "rblok_wall_japanese_top.obj",
	tiles = {
		lux_wood,
		--"homedecor_japanese_paper.png"
		"default_glass_detail.png"
	},
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {snappy=3},
	selection_box = jp_cbox,
	collision_box = jp_cbox,
	sounds = default.node_sound_wood_defaults(),
	})


minetest.register_node("rblok:rblok_acacia_wood", {
description = "rblok_acacia_wood ",
tiles = {"rblok_acacia_wood.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:rblok_aspen_wood", {
description = "rblok_aspen_wood ",
tiles = {"rblok_aspen_wood.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:rblok_pine_wood", {
description = "rblok_pine_wood ",
tiles = {"rblok_pine_wood.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:rblok_sandstone_block", {
description = "rblok_sandstone_block ",
tiles = {"rblok_sandstone_block.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:rblok_silver_sandstone_block", {
description = "rblok_silver_sandstone_block ",
tiles = {"rblok_silver_sandstone_block.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:rblok_stone_block", {
description = "rblok_stone_block ",
tiles = {"rblok_stone_block.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:rblok_glass", {
description = "rblok_glass ",
tiles = {"rblok_acacia_wood.png",
"rblok_acacia_wood.png",
"rblok_acacia_wood.png",
"rblok_acacia_wood.png",
"rblok_glass.png",
"rblok_glass.png",
},
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:fabric_darkgrey", {
description = "fabric_darkgrey ",
tiles = {"fabric_darkgrey.jpg" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:fabric_med_grey", {
description = "fabric_med_grey ",
tiles = {"fabric_med_grey.jpg" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:fabric_light_grey", {
description = "fabric_light_grey ",
tiles = {"fabric_light_grey.jpg" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:fabric_dark_cyan", {
description = "fabric_dark_cyan ",
tiles = {"fabric_dark_cyan.jpg" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:fabric_dark_orange", {
description = "fabric_dark_orange ",
tiles = {"fabric_dark_orange.jpg" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:fabric_black", {
description = "fabric_black ",
tiles = {"fabric_black.png" },
--walkable=false,
--paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

local table_table = { --name, material, invimg
{'light wood Table', 'woodtopa', 'woodtopa.png'},
{'dark wood Table', 'woodtopb', 'woodtopb.png'},
{'red Wood Table', 'woodtopc', 'woodtopc.png'},
{'light1 Wood Table', 'woodtopd', 'woodtopd.png'},
{'Grey Wood Table', 'dark_grey', 'dark_grey.png'},
{'grey1 Wood Table', 'bsside', 'bsside.png'}
}

for i in ipairs (table_table) do
	local name = table_table[i][1]
	local material = table_table[i][2]
	local invimg = table_table[i][3]

minetest.register_node('rblok:table_'..material, {
	description = name,
	drawtype = 'nodebox',
	tiles = {material..'.png'},
	inventory_image = invimg,
	groups = {snappy = 2, oddly_breakable_by_hand = 2, furniture = 1, flammable = 1},
	paramtype = 'light',
	paramtype2 = 'facedir',
	sounds = default.node_sound_wood_defaults(),
	node_box = {
       type = "fixed",
			 fixed = {
           {-0.5, -0.5, -0.5, -0.4, 0.0, -0.4},
           {-0.5, -0.5, 0.5, -0.4, 0.0, 0.4},
           {0.5, -0.5, -0.5, 0.4, 0.0, -0.4},
           {0.5, -0.5, 0.5, 0.4, 0.0, 0.4},
           {0.5, 0.1, 0.5, -0.5, 0.0, -0.5},
           {0.5, -0.3, 0.5, -0.5, -0.4, -0.5},
       },
	}
})
end

minetest.register_node("rblok:chair_silver2", {
description = "chair_silver2 ",
tiles = {"chair_silver.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:tile_white", {
description = "tile_white ",
tiles = {"tile_white.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:tile_white1", {
description = "tile_white1 ",
tiles = {"tile_white1.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:tile_color1", {
description = "tile_color1 ",
tiles = {"tile_color1.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:leather2", {
description = "leather2 ",
tiles = {"leather2.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:stone_wall", {
description = "stone_wall ",
tiles = {"stone_wall.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:woodtopd", {
description = "woodtopd ",
tiles = {"woodtopd.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:woodtopc", {
description = "woodtopc ",
tiles = {"woodtopc.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:woodtopb", {
description = "woodtopb ",
tiles = {"woodtopb.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:woodtopa", {
description = "woodtopa ",
tiles = {"woodtopa.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("rblok:leather1", {
description = "leather1 ",
tiles = {"leather1.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:ground_asphalt_a", {
description = "ground_asphalt_a ",
tiles = {"ground_asphalt_a.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:ground_asphalt_d", {
description = "ground_asphalt_d ",
tiles = {"ground_asphalt_d.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:ground_asphalt_c", {
description = "ground_asphalt_c ",
tiles = {"ground_asphalt_c.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:ground_asphalt_b", {
description = "ground_asphalt_b ",
tiles = {"ground_asphalt_b.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:grate001", {
description = "grate001 ",
tiles = {"grate001.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:brick_a", {
description = "brick_a ",
tiles = {"brick_a.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:brick_b", {
description = "brick_b ",
tiles = {"brick_b.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("rblok:tile_1", {
description = "tile 1",
tiles = {"tile_1.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:tiledark", {
description = "floor tile dark stone",
tiles = {"tiledark.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:colorbrick", {
description = "color stone paver",
tiles = {"colorbrick.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:fabrick_grey", {
description = "grey fabric",
tiles = {"fabric_grey.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:rstone", {
description = "deco stone",
tiles = {"rstone.jpg" },
walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:blackchair", {
description = "black chair",
drawtype = "mesh",
mesh = "rs_chair.obj",
tiles = {"black1.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",

selection_box = {
		type = 'fixed',
		fixed = {
			{-.4, -.4, -.3, .4, 0, .5},
			{-.4, 0, .3, .4, .62, .4},
			}
		},
	collision_box = {
		type = 'fixed',
		fixed = {
			{-.4, -.4, -.3, .4, 0, .5},
			{-.4, 0, .3, .4, .62, .4},
			}
		},

groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:chair_silver", {
description = "chair_silver",
drawtype = "mesh",
mesh = "rs_chair.obj",
tiles = {"chair_silver.png" },
--walkable=false,
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
selection_box = {
		type = 'fixed',
		fixed = {
			{-.4, -.4, -.3, .4, 0, .5},
			{-.4, 0, .3, .4, .62, .4},
			}
		},
	collision_box = {
		type = 'fixed',
		fixed = {
			{-.4, -.4, -.3, .4, 0, .5},
			{-.4, 0, .3, .4, .62, .4},
			}
		},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:darkgrey", {
description = "dark_grey_wood",
tiles = {"darkgrey.png" },
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:bluewood", {
description = "blue_wood",
tiles = {"bluewood.png" },
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

-- Drywall blocks

minetest.register_node("rblok:drywalltiledark", {
description = "carpet light orange",
tiles = {"tiledark.png", "baked_clay_white.png" },
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:carpetorange", {
description = "carpet light orange",
tiles = {"fabric_dark_orange.jpg", "baked_clay_white.png" },
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:carpetlightgrey", {
description = "carpet light grey",
tiles = {"fabric_light_grey.jpg", "baked_clay_white.png" },
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:carpetmedgrey", {
description = "carpet med grey",
tiles = {"fabric_med_grey.jpg", "baked_clay_white.png" },
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:carpetgrey", {
description = "carpet grey",
tiles = {"fabric_grey.png", "baked_clay_white.png" },
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:carpetdarkgrey", {
description = "carpet dark grey",
tiles = {"fabric_darkgrey.jpg", "baked_clay_white.png" },
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:drywalldarkgrey2", {
description = "dry wall grey2",
tiles = {"darkgrey.png", "baked_clay_white.png" },
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:drywalldarkgrey1", {
description = "dry wall darkgrey1",
tiles = {"dark_grey.png", "baked_clay_white.png" },
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:drywallwoodc", {
description = "dry wall woodc",
tiles = {"woodtopc.png", "baked_clay_white.png" },
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:drywallwoodb", {
description = "dry wall woodb",
tiles = {"woodtopb.png", "baked_clay_white.png" },
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:drywalltile_1", {
description = "dry wall tile",
tiles = {"tile_1.png", "baked_clay_white.png" },
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:drywallred", {
description = "dry wall red",
tiles = {"baked_clay_red.png", "baked_clay_white.png" },
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("rblok:drywallcgrey", {
description = "dry wall carpet grey",
tiles = {"drywallcgrey.jpg", "baked_clay_white.png" },
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:drywallcgreen", {
description = "dry wall carpet green",
tiles = {"baked_clay_green.png", "baked_clay_white.png" },
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:drywallmarble", {
description = "dry wall marble",
tiles = {"drywallmarble.png", "baked_clay_white.png" },
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok:drywalldirt", {
description = "dry wall dirt",
tiles = {"rdirt.jpg", "baked_clay_white.png" },
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

	minetest.register_node("rblok:sprucewood", {
	description = "sprucewood",
	tiles = {"sprucewood.png"},
	paramtype2 = "facedir",
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})


	minetest.register_node("rblok:applewood", {
	description = "applewood",
	tiles = {"applewood.png"},
	paramtype2 = "facedir",
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	minetest.register_node("rblok:birchwood", {
	description = "birchwood",
	tiles = {"birchwood.png"},
	paramtype2 = "facedir",
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	minetest.register_node("rblok:willowwood", {
	description = "willowwood",
	tiles = {"willowwood.png"},
	paramtype2 = "facedir",
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	minetest.register_node("rblok:wornwood", {
	description = "wornwood",
	tiles = {"wornwood256.png"},
	paramtype2 = "facedir",
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	minetest.register_node("rblok:floortile", {
	description = "floor_tile",
	tiles = {"floortilegreen.png"},
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	minetest.register_node("rblok:floortilegold", {
	description = "floor_tile_gold",
	tiles = {"floortilegold.png"},
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	minetest.register_node("rblok:floortilepitted", {
	description = "floor_tile_pitted",
	tiles = {"floortilepitted.png"},
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})


	minetest.register_node("rblok:planter", {
	description = "planter",
	tiles = {"plantertop.png",
	"bsside.png",
	"bsside.png",
	"bsside.png",
	"bsside.png",
	"bsside.png",
	},

	groups = {wood=2, oddly_breakable_by_hand = 3},

	})

minetest.register_node("rblok:bookswood", {
	description = "bookshelf wood",
	tiles = {"floorwood1a.jpg",
	"floorwood1a.jpg",
	"floorwood1a.jpg",
	"floorwood1a.jpg",
	"floorwood1a.jpg",
	"bookshelffront.png",
	},
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {wood=2, oddly_breakable_by_hand = 3},

	})

	minetest.register_node("rblok:books", {
	description = "bookshelf",
	tiles = {"bsside.png",
	"bsside.png",
	"bsside.png",
	"bsside.png",
	"bsside.png",
	"bookshelffront.png",
	},
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {wood=2, oddly_breakable_by_hand = 3},

	})

	minetest.register_node("rblok:rblokbook", {
	description = "bookshelf",
	tiles = {"rblok_pine_wood.png",
	"rblok_pine_wood.png",
	"rblok_pine_wood.png",
	"rblok_pine_wood.png",
	"rblok_pine_wood.png",
	"rblokbook.png",
	},
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {wood=2, oddly_breakable_by_hand = 3},

	})

	minetest.register_node("rblok:lightblock", {
	description = "lightblock",
	tiles = {"bsside.png",
	"bsside.png",
	"rlight.png",
	"rlight.png",
	"rlight.png",
	"rlight.png",
	},
	groups = {oddly_breakable_by_hand = 3},
	sounds = default.node_sound_glass_defaults(),
			--light_source = 10,
			light_source = default.LIGHT_MAX-1,
			use_texture_alpha = true,
			paramtype="light",
			--sunlight_propagates = true,

	})

  minetest.register_node("rblok:lightblock1", {
  description = "lightblock1",
  tiles = {"baked_clay_white.png",
  "baked_clay_white.png",
  "rlight1.png",
  "rlight1.png",
  "rlight1.png",
  "rlight1.png",
  },
  groups = {oddly_breakable_by_hand = 3},
  sounds = default.node_sound_glass_defaults(),
      --light_source = 10,
      light_source = default.LIGHT_MAX-1,
      use_texture_alpha = true,
      paramtype="light",
      --sunlight_propagates = true,

  })

	-- minetest.register_node("rblok:planter3", {
  --  description = "Planter3",
  --  drawtype = "mesh",
  --  mesh = "planter3aa.obj",
  --  tiles = {name="planter3.png"},
  --  groups = {choppy=2, dig_immediate=2},
  --  paramtype = "light",
  --  paramtype2 = "facedir",
  --  selection_box = {
  --     type = "fixed",
  --     fixed = {-.5, -.5, -.5, .5, .5, .5},
  --     },
  --  collision_box = {
  --     type = "fixed",
  --     fixed = {-.5, -.5, -.5, .5, .5, .5},
  --     },
  --     })

  minetest.register_node("rblok:flowerpot1", {
   description = "flowerpot1",
   drawtype = "mesh",
   mesh = "flowerpot1.obj",
   --tiles = {name="flowerpot256.png"},
   groups = {choppy=2, dig_immediate=2},
   paramtype = "light",
   paramtype2 = "facedir",
   selection_box = {
      type = "fixed",
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
   collision_box = {
      type = "fixed",
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
      })

minetest.register_node("rblok:vase", {
   description = "vase",
   drawtype = "mesh",
   mesh = "vase.obj",
   tiles = {name="vase.png"},
   groups = {choppy=2, dig_immediate=2},
   paramtype = "light",
   paramtype2 = "facedir",
   selection_box = {
      type = "fixed",
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
   collision_box = {
      type = "fixed",
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
      })

minetest.register_node("rblok:vase1", {
   description = "vase1",
   drawtype = "mesh",
   mesh = "vase1.obj",
   tiles = {name="vase1.png"},
   groups = {choppy=2, dig_immediate=2},
   paramtype = "light",
   paramtype2 = "facedir",
   selection_box = {
      type = "fixed",
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
   collision_box = {
      type = "fixed",
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
      })

minetest.register_node("rblok:vase2", {
   description = "vase2",
   drawtype = "mesh",
   mesh = "vase2.obj",
   tiles = {name="vase2.png"},
   groups = {choppy=2, dig_immediate=2},
   paramtype = "light",
   paramtype2 = "facedir",
   selection_box = {
      type = "fixed",
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
   collision_box = {
      type = "fixed",
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
      })

minetest.register_node("rblok:donuts", {
   description = "donut",
   drawtype = "mesh",
   mesh = "donut.obj",
   tiles = {name="donut1.png"},
   groups = {choppy=2, dig_immediate=2},
   paramtype = "light",
   paramtype2 = "facedir",
   selection_box = {
      type = "fixed",
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
   collision_box = {
      type = "fixed",
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
      })

      minetest.register_node("rblok:donut2", {
   description = "donut2",
   drawtype = "mesh",
   mesh = "donut1.obj",
   tiles = {name="donut2.png"},
   groups = {choppy=2, dig_immediate=2},
   paramtype = "light",
   paramtype2 = "facedir",
   selection_box = {
      type = "fixed",
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
   collision_box = {
      type = "fixed",
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
      })


minetest.register_node("rblok:shapeTest", {
   description = "shapeTest",
   drawtype = "mesh",
   mesh = "shapTest.obj",
   tiles = {name="wool_khaki.jpg"},
   groups = {choppy=2, dig_immediate=2},
   light_source = default.LIGHT_MAX-2,
			--use_texture_alpha = true,
			paramtype="light",
   selection_box = {
      type = "fixed",
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
   collision_box = {
      type = "fixed",
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
      })

minetest.register_node("rblok:flowerpot22", {
   description = "flowerpot22",
   drawtype = "mesh",
   mesh = "flowerpot22.obj",
   tiles = {name="flowerpot22A.png"},
   groups = {choppy=2, dig_immediate=2},
   paramtype = "light",
   paramtype2 = "facedir",
   selection_box = {
      type = "fixed",
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
   collision_box = {
      type = "fixed",
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
      })

      minetest.register_node("rblok:flowerpotthin", {
   description = "flowerpot_thin",
   drawtype = "mesh",
   mesh = "flowerpotthin.obj",
   tiles = {name="flowerpot22A.png"},
   groups = {choppy=2, dig_immediate=2},
   paramtype = "light",
   paramtype2 = "facedir",
   selection_box = {
      type = "fixed",
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
   collision_box = {
      type = "fixed",
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
      })





			minetest.register_node("rblok:thinRGS", {
			description = "flowerpot_thinRGS",
			drawtype = "mesh",
			mesh = "flowerpotthinFINAL1.obj",
			tiles = {name="thin_dirt.jpg", "baked_clay_white.png"},
			groups = {choppy=2, dig_immediate=2},
			paramtype = "light",
			paramtype2 = "facedir",
			selection_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			collision_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			})

--newUV
			minetest.register_node("rblok:potthinuv", {
			description = "flowerpot_new2",
			drawtype = "mesh",
			mesh = "potthinuv.obj",
			tiles = {name= "technic_blast_resistant_concrete_block.jpg", "thin_dirt.jpg"},
			groups = {choppy=2, dig_immediate=2},
			paramtype = "light",
			paramtype2 = "facedir",
			selection_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			collision_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			})

			minetest.register_node("rblok:potthinuvgreen", {
			description = "green",
			drawtype = "mesh",
			mesh = "potthinuv.obj",
			tiles = {name= "baked_clay_green.png", "thin_dirt.jpg"},
			groups = {choppy=2, dig_immediate=2},
			paramtype = "light",
			paramtype2 = "facedir",
			selection_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			collision_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			})

			minetest.register_node("rblok:potthinuvred", {
			description = "red",
			drawtype = "mesh",
			mesh = "potthinuv.obj",
			tiles = {name= "baked_clay_red.png", "thin_dirt.jpg"},
			groups = {choppy=2, dig_immediate=2},
			paramtype = "light",
			paramtype2 = "facedir",
			selection_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			collision_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			})

			minetest.register_node("rblok:potthinuvgrey", {
			description = "grey",
			drawtype = "mesh",
			mesh = "potthinuv.obj",
			tiles = {name= "dark_grey.png", "thin_dirt.jpg"},
			groups = {choppy=2, dig_immediate=2},
			paramtype = "light",
			paramtype2 = "facedir",
			selection_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			collision_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			})
--use this
			minetest.register_node("rblok:thinRGS1", {
			description = "flowerpot_thinRGS1",
			drawtype = "mesh",
			mesh = "flowerpotthinFINAL1.obj",
			tiles = {name="thin_dirt.jpg", "dark_grey.png"},
			groups = {choppy=2, dig_immediate=2},
			paramtype = "light",
			paramtype2 = "facedir",
			selection_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			collision_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			})

			minetest.register_node("rblok:chair1", {
			description = "test_Chair",
			drawtype = "mesh",
			mesh = "chair1.obj",
			tiles = {name="wool_dgrey.jpg"},
			groups = {choppy=2, dig_immediate=2},
			paramtype = "light",
			paramtype2 = "facedir",
			selection_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			collision_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			})

			minetest.register_node("rblok:chair5", {
			description = "test_Chair5",
			drawtype = "mesh",
			mesh = "chair1aafinal.obj",
			tiles = {name="wool_dgrey.jpg"},
			groups = {choppy=2, dig_immediate=2},
			paramtype = "light",
			paramtype2 = "facedir",
			selection_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			collision_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			})

			minetest.register_node("rblok:chair2", {
			description = "test_Chair2",
			drawtype = "mesh",
			mesh = "chair2.obj",
			tiles = {name="wool_dgrey.jpg"},
			groups = {choppy=2, dig_immediate=2},
			paramtype = "light",
			paramtype2 = "facedir",
			selection_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			collision_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			})

			minetest.register_node("rblok:chairuvtest", {
			description = "chairUVtest",
			drawtype = "mesh",
			mesh = "chairuvtest1.obj",
			tiles = {name="wool_dgrey.jpg"},
			groups = {choppy=2, dig_immediate=2},
			paramtype = "light",
			paramtype2 = "facedir",
			selection_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			collision_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			})

			minetest.register_node("rblok:chair_leather1", {
			description = "chair_leather",
			drawtype = "mesh",
			mesh = "chairuvtest1.obj",
			tiles = {name="leather2.png"},
			groups = {choppy=2, dig_immediate=2},
			paramtype = "light",
			paramtype2 = "facedir",
			selection_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			collision_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			})

			minetest.register_node("rblok:sofa_leather1", {
			description = "sofa_leather1",
			drawtype = "mesh",
			mesh = "sofa2.obj",
			tiles = {name="leather2.png"},
			groups = {choppy=2, dig_immediate=2},
			paramtype = "light",
			paramtype2 = "facedir",
			selection_box = {
				type = 'fixed',
				fixed = {
					{-.5, -.5, -.5, .5, 0, .5}, --Right, Bottom, Back, Left, Top, Front
					{-.5, 0, .5, .5, .5, .2},
					{-.65, -.15, -.45, -.45, .3, .25}, --left
					{.65, -.15, -.45, .45, .3, .25}, --right
					},
				},
			collision_box = {
				type = 'fixed',
				fixed = {
					{-.5, -.5, -.5, .5, 0, .5}, --base
					{-.5, 0, .5, .5, .5, .2}, --back
					{-.65, -.15, -.45, -.45, .3, .25}, --left
					{.65, -.15, -.45, .45, .3, .25}, --right
					},
				},

			})

			minetest.register_node("rblok:sofa_leather2", {
			description = "sofa_leather2",
			drawtype = "mesh",
			mesh = "sofa2.obj",
			tiles = {name="leather_black_03.png"},
			groups = {choppy=2, dig_immediate=2},
			paramtype = "light",
			paramtype2 = "facedir",
			selection_box = {
				type = 'fixed',
				fixed = {
					{-.5, -.5, -.5, .5, 0, .5}, --Right, Bottom, Back, Left, Top, Front
					{-.5, 0, .5, .5, .5, .2},
					{-.65, -.15, -.45, -.45, .3, .25}, --left
					{.65, -.15, -.45, .45, .3, .25}, --right
					},
				},
			collision_box = {
				type = 'fixed',
				fixed = {
					{-.5, -.5, -.5, .5, 0, .5}, --base
					{-.5, 0, .5, .5, .5, .2}, --back
					{-.65, -.15, -.45, -.45, .3, .25}, --left
					{.65, -.15, -.45, .45, .3, .25}, --right
					},
				},

			})


			minetest.register_node("rblok:sofa_leather3", {
			description = "sofa_leather3",
			drawtype = "mesh",
			mesh = "sofa2.obj",
			tiles = {name="chair_silver.png"},
			groups = {choppy=2, dig_immediate=2},
			paramtype = "light",
			paramtype2 = "facedir",
			selection_box = {
				type = 'fixed',
				fixed = {
					{-.5, -.5, -.5, .5, 0, .5}, --Right, Bottom, Back, Left, Top, Front
					{-.5, 0, .5, .5, .5, .2},
					{-.65, -.15, -.45, -.45, .3, .25}, --left
					{.65, -.15, -.45, .45, .3, .25}, --right
					},
				},
			collision_box = {
				type = 'fixed',
				fixed = {
					{-.5, -.5, -.5, .5, 0, .5}, --base
					{-.5, 0, .5, .5, .5, .2}, --back
					{-.65, -.15, -.45, -.45, .3, .25}, --left
					{.65, -.15, -.45, .45, .3, .25}, --right
					},
				},

			})

			minetest.register_node("rblok:sofa_leather3corner", {
			description = "sofa_leather3corner",
			drawtype = "mesh",
			mesh = "rs_sofa_c.obj",
			tiles = {name="chair_silver.png"},
			groups = {choppy=2, dig_immediate=2},
			paramtype = "light",
			paramtype2 = "facedir",
			selection_box = {
		type = 'fixed',
		fixed = {
			{-.5, -.5, -.5, .5, 0, .5}, --bottom
			{-.5, 0, .5, .5, .5, .2}, --back
			{.2, 0, -.5, .5, .5, .2}, --side
			}
		},
	collision_box = {
		type = 'fixed',
		fixed = {
			{-.5, -.5, -.5, .5, 0, .5},
			{-.5, 0, .5, .5, .5, .2},
			}
		},
			})

      minetest.register_node("rblok:sofa_BRleather3corner", {
			description = "sofa_leather3corner",
			drawtype = "mesh",
			mesh = "rs_sofa_c.obj",
			tiles = {name="leather2.png"},
			groups = {choppy=2, dig_immediate=2},
			paramtype = "light",
			paramtype2 = "facedir",
			selection_box = {
		type = 'fixed',
		fixed = {
			{-.5, -.5, -.5, .5, 0, .5}, --bottom
			{-.5, 0, .5, .5, .5, .2}, --back
			{.2, 0, -.5, .5, .5, .2}, --side
			}
		},
	collision_box = {
		type = 'fixed',
		fixed = {
			{-.5, -.5, -.5, .5, 0, .5},
			{-.5, 0, .5, .5, .5, .2},
			}
		},
			})

			minetest.register_node("rblok:sofa_leather3right", {
			description = "sofa_leather3right",
			drawtype = "mesh",
			mesh = "rs_sofa_r.obj",
			tiles = {name="chair_silver.png"},
			groups = {choppy=2, dig_immediate=2},
			paramtype = "light",
			paramtype2 = "facedir",
			selection_box = {
				type = 'fixed',
				fixed = {
					{-.5, -.5, -.5, .5, 0, .5},
					{-.5, 0, .5, .5, .5, .2},
					{-.65, -.15, -.45, -.45, .3, .25},
					}
				},
			collision_box = {
				type = 'fixed',
				fixed = {
					{-.5, -.5, -.5, .5, 0, .5},
					{-.5, 0, .5, .5, .5, .2},
					{-.65, -.15, -.45, -.45, .3, .25},
					}
				},
			})

      minetest.register_node("rblok:sofa_BRleather3right", {
			description = "sofa_leather3right",
			drawtype = "mesh",
			mesh = "rs_sofa_r.obj",
			tiles = {name="leather2.png"},
			groups = {choppy=2, dig_immediate=2},
			paramtype = "light",
			paramtype2 = "facedir",
			selection_box = {
				type = 'fixed',
				fixed = {
					{-.5, -.5, -.5, .5, 0, .5},
					{-.5, 0, .5, .5, .5, .2},
					{-.65, -.15, -.45, -.45, .3, .25},
					}
				},
			collision_box = {
				type = 'fixed',
				fixed = {
					{-.5, -.5, -.5, .5, 0, .5},
					{-.5, 0, .5, .5, .5, .2},
					{-.65, -.15, -.45, -.45, .3, .25},
					}
				},
			})

			minetest.register_node("rblok:sofa_leather3left", {
			description = "sofa_leather3left",
			drawtype = "mesh",
			mesh = "rs_sofa_l.obj",
			tiles = {name="chair_silver.png"},
			groups = {choppy=2, dig_immediate=2},
			paramtype = "light",
			paramtype2 = "facedir",
			selection_box = {
				type = 'fixed',
				fixed = {
					{-.5, -.5, -.5, .5, 0, .5},
					{-.5, 0, .5, .5, .5, .2},
					{.65, -.15, -.45, .45, .3, .25},
					}
				},
			collision_box = {
				type = 'fixed',
				fixed = {
					{-.5, -.5, -.5, .5, 0, .5},
					{-.5, 0, .5, .5, .5, .2},
					{.65, -.15, -.45, .45, .3, .25},
					}
				},
			})

      minetest.register_node("rblok:sofa_BRleather3left", {
			description = "sofa_leather3left",
			drawtype = "mesh",
			mesh = "rs_sofa_l.obj",
			tiles = {name="leather2.png"},
			groups = {choppy=2, dig_immediate=2},
			paramtype = "light",
			paramtype2 = "facedir",
			selection_box = {
				type = 'fixed',
				fixed = {
					{-.5, -.5, -.5, .5, 0, .5},
					{-.5, 0, .5, .5, .5, .2},
					{.65, -.15, -.45, .45, .3, .25},
					}
				},
			collision_box = {
				type = 'fixed',
				fixed = {
					{-.5, -.5, -.5, .5, 0, .5},
					{-.5, 0, .5, .5, .5, .2},
					{.65, -.15, -.45, .45, .3, .25},
					}
				},
			})

			minetest.register_node("rblok:sofa_leather3middle", {
			description = "sofa_leather3middle",
			drawtype = "mesh",
			mesh = "rs_sofa_m.obj",
			tiles = {name="chair_silver.png"},
			groups = {choppy=2, dig_immediate=2},
			paramtype = "light",
			paramtype2 = "facedir",
			selection_box = {
				type = 'fixed',
				fixed = {
					{-.5, -.5, -.5, .5, 0, .5},
					{-.5, 0, .5, .5, .5, .2},
					}
				},
			collision_box = {
				type = 'fixed',
				fixed = {
					{-.5, -.5, -.5, .5, 0, .5},
					{-.5, 0, .5, .5, .5, .2},
					}
				},
			})

      minetest.register_node("rblok:sofa_BRleather3middle", {
			description = "sofa_leather3middle",
			drawtype = "mesh",
			mesh = "rs_sofa_m.obj",
			tiles = {name="leather2.png"},
			groups = {choppy=2, dig_immediate=2},
			paramtype = "light",
			paramtype2 = "facedir",
			selection_box = {
				type = 'fixed',
				fixed = {
					{-.5, -.5, -.5, .5, 0, .5},
					{-.5, 0, .5, .5, .5, .2},
					}
				},
			collision_box = {
				type = 'fixed',
				fixed = {
					{-.5, -.5, -.5, .5, 0, .5},
					{-.5, 0, .5, .5, .5, .2},
					}
				},
			})


			minetest.register_node("rblok:chair_leather2", {
			description = "chair_leather2",
			drawtype = "mesh",
			mesh = "chairuvtest1.obj",
			tiles = {name="leather_black_03.png"},
			groups = {choppy=2, dig_immediate=2},
			paramtype = "light",
			paramtype2 = "facedir",
			selection_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			collision_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			})

			minetest.register_node("rblok:chair_fabric_grey", {
			description = "chair_fabric_grey",
			drawtype = "mesh",
			mesh = "chairuvtest1.obj",
			tiles = {name="fabric_grey.png"},
			groups = {choppy=2, dig_immediate=2},
			paramtype = "light",
			paramtype2 = "facedir",
			selection_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			collision_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			})

			minetest.register_node("rblok:chair_leather3", {
			description = "chair_leather3",
			drawtype = "mesh",
			mesh = "chairuvtest1.obj",
			tiles = {name="leather1.png"},
			groups = {choppy=2, dig_immediate=2},
			paramtype = "light",
			paramtype2 = "facedir",
			selection_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			collision_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			})

			minetest.register_node("rblok:chair_leather4", {
			description = "chair_leather4",
			drawtype = "mesh",
			mesh = "chairuvtest1.obj",
			tiles = {name="chair_silver.png"},
			groups = {choppy=2, dig_immediate=2},
			paramtype = "light",
			paramtype2 = "facedir",
			selection_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			collision_box = {
			type = "fixed",
			fixed = {-.5, -.5, -.5, .5, .5, .5},
			},
			})

minetest.register_node('rblok:tvrgs', {
   description = 'tv',
   drawtype = 'mesh',
   mesh = 'tv2.obj',
   tiles = {name='bsside.png'},
   groups = {choppy=2, dig_immediate=2,},
   paramtype = 'light',
   paramtype2 = 'facedir',
   selection_box = {
      type = 'fixed',
      fixed = {-.5, -.5, -.5, .5, -.4, .5},
      },
   collision_box = {
      type = 'fixed',
      fixed = {-.5, -.5, -.5, .5, -.4, .5},
      },
   on_place = minetest.rotate_node
})





  minetest.register_node('rblok:rvase', {
   description = 'rvase',
   drawtype = 'mesh',
   mesh = 'rvase.obj',
   tiles = {name= 'rvasetile.png'},
   --tiles = {name= 'rvasetileM3.png'},
   groups = {choppy=2, dig_immediate=2,},
   paramtype = 'light',
   paramtype2 = 'facedir',
   selection_box = {
      type = 'fixed',
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
   collision_box = {
      type = 'fixed',
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
   --on_place = minetest.rotate_node
})


minetest.register_node('rblok:flmat', {
   description = 'flower_material',
   drawtype = 'mesh',
   mesh = 'flmat.obj',
   tiles = {name= 'marble.jpg','dirt.jpg'},
   groups = {choppy=2, dig_immediate=2,},
   paramtype = 'light',
   paramtype2 = 'facedir',
   selection_box = {
      type = 'fixed',
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
   collision_box = {
      type = 'fixed',
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
   --on_place = minetest.rotate_node
})


minetest.register_node('rblok:thin20', {
   description = 'reworked_thin',
   drawtype = 'mesh',
   mesh = 'thinplantfinal.obj',
   tiles = {name= 'thin_dirt.jpg', 'dark_grey.png'},
   groups = {choppy=2, dig_immediate=2,},
   paramtype = 'light',
   paramtype2 = 'facedir',
   selection_box = {
      type = 'fixed',
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
   collision_box = {
      type = 'fixed',
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
   --on_place = minetest.rotate_node
})

minetest.register_node('rblok:mirrorfaucet1', {
   description = 'mirror faucet 1',
   drawtype = 'mesh',
   mesh = 'mirrowfaucet1.obj',
   --tiles = {name='steel.jpg','bsside.png'},
    tiles = {name='rcarbon.jpg','steel.jpg'},
   groups = {choppy=2, dig_immediate=2,},
   paramtype = 'light',
   paramtype2 = 'facedir',
   selection_box = {
		type = "fixed",
		fixed = { -4/16, -7/16, 4/16, 4/16, -4/16, 8/16 },
		},
		collision_box = {
		type = "fixed",
		fixed = { -4/16, -7/16, 4/16, 4/16, -4/16, 8/16 },
   },
})

minetest.register_node('rblok:coffeecup2', {
   description = 'coffeecup2',
   drawtype = 'mesh',
   mesh = 'coffeecup2.obj',
   --tiles = {name='steel.jpg','bsside.png'},
    tiles = {name='cup.png'},
   groups = {choppy=2, dig_immediate=2,},
   paramtype = 'light',
   paramtype2 = 'facedir',
	 selection_box = {
      type = 'fixed',
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
   collision_box = {
      type = 'fixed',
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
})

minetest.register_node('rblok:coffeecup2ab', {
   description = 'coffeecup2ab',
   drawtype = 'mesh',
   mesh = 'coffeecup2ab.obj',
   --tiles = {name='steel.jpg','bsside.png'},
    tiles = {name='cup.png','decanter.png'},
   groups = {choppy=2, dig_immediate=2,},
   paramtype = 'light',
   paramtype2 = 'facedir',
	 selection_box = {
      type = 'fixed',
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
   collision_box = {
      type = 'fixed',
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
})

minetest.register_node('rblok:tvtest1', {
   description = 'tvtest',
   drawtype = 'mesh',
   mesh = 'tvtest.obj',
  tiles = {name='tvtestout1.png'},
	--tiles = {name='crazy.png'},
    --tiles = {name='screen.png','base.png'},
   groups = {choppy=2, dig_immediate=2,},
   paramtype = 'light',
   paramtype2 = 'facedir',
	 selection_box = {
      type = 'fixed',
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
   collision_box = {
      type = 'fixed',
      fixed = {-.5, -.5, -.5, .5, .5, .5},
      },
})


minetest.register_node('rblok:paintingM1', {
   description = 'paintingM1',
   drawtype = 'mesh',
   mesh = 'painting.obj',
   --tiles = {name='steel.jpg','bsside.png'},
    tiles = {name= 'mosaicpainting.png'},
   groups = {choppy=2, dig_immediate=2,},
   paramtype = 'light',
   paramtype2 = 'facedir',
	 selection_box = {
      type = 'fixed',
      fixed = {-.5, -.5, -.5, .5, -.4, .5},
      },
   collision_box = {
      type = 'fixed',
      fixed = {-.5, -.5, -.5, .5, -.4, .5},
      },
   on_place = minetest.rotate_node

 })



 minetest.register_node('rblok:ytplaque', {
    description = 'ytplaque',
    drawtype = 'mesh',
    mesh = 'picfrmsmall1.obj',
    --tiles = {name='steel.jpg','bsside.png'},
     tiles = {name= 'picfrmsmalldone256Final.png'},
    groups = {choppy=2, dig_immediate=2,},
    paramtype = 'light',
    paramtype2 = 'facedir',
		selection_box = {
       type = 'fixed',
       fixed = {-.5, -.5, -.5, .5, -.4, .5},
       },
    collision_box = {
       type = 'fixed',
       fixed = {-.5, -.5, -.5, .5, -.4, .5},
       },
    on_place = minetest.rotate_node

  })

	minetest.register_node('rblok:ytplaque1', {
     description = 'ytplaque512',
     drawtype = 'mesh',
     mesh = 'picfrmsmall1.obj',
     --tiles = {name='steel.jpg','bsside.png'},
      tiles = {name= 'picfrmsmall512.png'},
     groups = {choppy=2, dig_immediate=2,},
     paramtype = 'light',
     paramtype2 = 'facedir',
 		selection_box = {
        type = 'fixed',
        fixed = {-.5, -.5, -.5, .5, -.4, .5},
        },
     collision_box = {
        type = 'fixed',
        fixed = {-.5, -.5, -.5, .5, -.4, .5},
        },
     on_place = minetest.rotate_node

   })

	 minetest.register_node('rblok:ytplaque2', {
      description = 'ytplaque2',
      drawtype = 'mesh',
      mesh = 'picfrmsmall1.obj',
      --tiles = {name='steel.jpg','bsside.png'},
       tiles = {name= 'picfrmsmallPT2g4.png'},
      groups = {choppy=2, dig_immediate=2,},
      paramtype = 'light',
      paramtype2 = 'facedir',
  		selection_box = {
         type = 'fixed',
         fixed = {-.5, -.5, -.5, .5, -.4, .5},
         },
      collision_box = {
         type = 'fixed',
         fixed = {-.5, -.5, -.5, .5, -.4, .5},
         },
      on_place = minetest.rotate_node

    })

		minetest.register_node('rblok:cert2', {
			 description = 'cert2',
			 drawtype = 'mesh',
			 mesh = 'picfrmsmall1.obj',
			 --tiles = {name='steel.jpg','bsside.png'},
				tiles = {name= 'cert2512.png'},
			 groups = {choppy=2, dig_immediate=2,},
			 paramtype = 'light',
			 paramtype2 = 'facedir',
			 selection_box = {
					type = 'fixed',
					fixed = {-.5, -.5, -.5, .5, -.4, .5},
					},
			 collision_box = {
					type = 'fixed',
					fixed = {-.5, -.5, -.5, .5, -.4, .5},
					},
			 on_place = minetest.rotate_node

		 })
     minetest.register_node('rblok:cert2a', {
        description = 'cert2a',
        drawtype = 'mesh',
        mesh = 'picfrmsmall1.obj',
        --tiles = {name='steel.jpg','bsside.png'},
         tiles = {name= 'cert2512a.png'},
        groups = {choppy=2, dig_immediate=2,},
        paramtype = 'light',
        paramtype2 = 'facedir',
        selection_box = {
           type = 'fixed',
           fixed = {-.5, -.5, -.5, .5, -.4, .5},
           },
        collision_box = {
           type = 'fixed',
           fixed = {-.5, -.5, -.5, .5, -.4, .5},
           },
        on_place = minetest.rotate_node

      })

		 minetest.register_node("rblok:toolbox", {
	description = ("test_object"),
	drawtype = 'mesh',
	mesh = "newtoolfinal1.obj",
	--tiles ={name = "toolbake.png" },
	tiles ={name = "newbakedtoolfinal.png" },
	groups = { snappy=3 },
	paramtype = 'light',
	paramtype2 = 'facedir',
	selection_box = {
		 type = 'fixed',
		 fixed = {-.5, -.5, -.5, .5, .5, .5},
		 },
	collision_box = {
		 type = 'fixed',
		 fixed = {-.5, -.5, -.5, .5, .5, .5},
		 },
		 --on_place = minetest.rotate_node

})

minetest.register_node("rblok:toolbox1", {
description = ("test_light"),
drawtype = 'mesh',
mesh = "newtoollight.obj",
--tiles ={name = "toolbake.png" },
tiles ={name = "lighttest2.png" },
groups = { snappy=3 },
paramtype = 'light',
paramtype2 = 'facedir',
selection_box = {
type = 'fixed',
fixed = {-.5, -.5, -.5, .5, .5, .5},
},
collision_box = {
type = 'fixed',
fixed = {-.5, -.5, -.5, .5, .5, .5},
},
--on_place = minetest.rotate_node

})

minetest.register_node("rblok:cubetest", {
description = ("glass_cube"),
drawtype = 'mesh',
mesh = "cubetestlight.obj",
--tiles ={name = "toolbake.png" },
tiles ={name = "glass1.png" },
groups = { snappy=3 },
paramtype = 'light',
--paramtype2 = 'facedir',
use_texture_alpha = true,
sunlight_propagates = true,
selection_box = {
type = 'fixed',
fixed = {-.5, -.5, -.5, .5, .5, .5},
},
collision_box = {
type = 'fixed',
fixed = {-.5, -.5, -.5, .5, .5, .5},
},
--on_place = minetest.rotate_node

})


--stairsplus registration

if minetest.get_modpath("moreblocks") then

stairsplus:register_all("rblok", "Tanwood2", "rblok:Tanwood2", {
  description = "tan wood2",
  tiles = {"woodtopb.png","tan2.png"},
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })
  
  stairsplus:register_all("rblok", "Tantile2", "rblok:Tantile2", {
  description = "tan tile2",
  tiles = {"tile_white.png","tan2.png"},
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })
  
  stairsplus:register_all("rblok", "flcpcyan", "rblok:flcpcyan", {
  description = "flcpcyan",
  tiles = {"fabric_dark_cyan.jpg","floorwood1a.jpg"},
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })

  stairsplus:register_all("rblok", "flcporange", "rblok:flcporange", {
  description = "flcporange",
  tiles = {"fabric_dark_orange.jpg","floorwood1a.jpg"},
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })

  stairsplus:register_all("rblok", "flcpgrey", "rblok:flcpgrey", {
  description = "flcpgrey",
  tiles = {"fabric_grey.png","floorwood1a.jpg"},
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })

  stairsplus:register_all("rblok", "flcpdrgrey", "rblok:flcpdrgrey", {
  description = "fabric_darkgrey",
  tiles = {"fabric_darkgrey.jpg","floorwood1a.jpg"},
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })

  stairsplus:register_all("rblok", "floorwood1a", "rblok:floorwood1a", {
  description = "floorwood1a",
  tiles = {"floorwood1a.jpg"
  },
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })

  stairsplus:register_all("rblok", "floorwood2b", "rblok:floorwood2b", {
  description = "floorwood2b",
  tiles = {"floorwood2a.jpg"
  },
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })

  stairsplus:register_all("rblok", "techConcreteGrey", "rblok:techConcreteGrey", {
	description = "techConcreteGrey",
	tiles = {"fabric_grey.png", "technic_blast_resistant_concrete_block1.jpg"
 },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})


  stairsplus:register_all("rblok", "techConcreteDGrey", "rblok:techConcreteDGrey", {
  description = "techConcreteDGrey",
  tiles = {"fabric_darkgrey.jpg", "technic_blast_resistant_concrete_block1.jpg"
  },
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })


	stairsplus:register_all("rblok", "rblok_stone_block", "rblok:rblok_stone_block", {
	description = "rblok_stone_block",
	tiles = {"rblok_stone_block.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "rblok_silver_sandstone_block", "rblok:rblok_silver_sandstone_block", {
	description = "rblok_silver_sandstone_block",
	tiles = {"rblok_silver_sandstone_block.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "rblok_sandstone_block", "rblok:rblok_sandstone_block", {
	description = "rblok_sandstone_block",
	tiles = {"rblok_sandstone_block.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "rblok_pine_wood", "rblok:rblok_pine_wood", {
	description = "rblok_pine_wood",
	tiles = {"rblok_pine_wood.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})


	stairsplus:register_all("rblok", "rblok_aspen_wood", "rblok:rblok_aspen_wood", {
	description = "rblok_aspen_wood",
	tiles = {"rblok_aspen_wood.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "rblok_acacia_wood", "rblok:rblok_acacia_wood", {
	description = "rblok_acacia_wood",
	tiles = {"rblok_acacia_wood.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "fabric_med_grey", "rblok:fabric_med_grey", {
	description = "fabric_med_grey",
	tiles = {"fabric_med_grey.jpg" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "fabric_darkgrey", "rblok:fabric_darkgrey", {
	description = "fabric_darkgrey",
	tiles = {"fabric_darkgrey.jpg" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
})

	stairsplus:register_all("rblok", "fabric_light_grey", "rblok:fabric_light_grey", {
	description = "fabric_light_grey",
	tiles = {"fabric_light_grey.jpg" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "fabric_dark_cyan", "rblok:fabric_dark_cyan", {
	description = "fabric_dark_cyan",
	tiles = {"fabric_dark_cyan.jpg" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "fabric_dark_orange", "rblok:fabric_dark_orange", {
	description = "fabric_dark_orange",
	tiles = {"fabric_dark_orange.jpg" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "fabric_black", "rblok:fabric_black", {
	description = "fabric_black",
	tiles = {"fabric_black.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})


	stairsplus:register_all("rblok", "chair_silver2", "rblok:chair_silver2", {
	description = "chair_silver2",
	tiles = {"chair_silver.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "stone_wall", "rblok:stone_wall", {
	description = "stone_wall",
	tiles = {"stone_wall.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "leather2", "rblok:leather2", {
	description = "leather2",
	tiles = {"leather2.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})


	stairsplus:register_all("rblok", "woodtopd", "rblok:woodtopd", {
	description = "woodtopd",
	tiles = {"woodtopd.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "woodtopc", "rblok:woodtopc", {
	description = "woodtopc",
	tiles = {"woodtopc.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "woodtopb", "rblok:woodtopb", {
	description = "woodtopb",
	tiles = {"woodtopb.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "woodtopa", "rblok:woodtopa", {
	description = "woodtopa",
	tiles = {"woodtopa.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "leather1", "rblok:leather1", {
	description = "leather1",
	tiles = {"leather1.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "ground_asphalt_a", "rblok:ground_asphalt_a", {
	description = "ground_asphalt_a",
	tiles = {"ground_asphalt_a.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "ground_asphalt_d", "rblok:ground_asphalt_d", {
	description = "ground_asphalt_d",
	tiles = {"ground_asphalt_d.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "ground_asphalt_c", "rblok:ground_asphalt_c", {
	description = "ground_asphalt_c",
	tiles = {"ground_asphalt_c.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "ground_asphalt_b", "rblok:ground_asphalt_b", {
	description = "ground_asphalt_b",
	tiles = {"ground_asphalt_b.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "grate001", "rblok:grate001", {
	description = "grate001",
	tiles = {"grate001.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "brick_a", "rblok:brick_a", {
	description = "brick_a",
	tiles = {"brick_a.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "brick_b", "rblok:brick_b", {
	description = "brick_b",
	tiles = {"brick_b.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "tile_1", "rblok:tile_1", {
	description = "tile_1",
	tiles = {"tile_1.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "tiledark", "rblok:tiledark", {
	description = "tiledark",
	tiles = {"tiledark.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "colorbrick", "rblok:colorbrick", {
	description = "colorbrick",
	tiles = {"colorbrick.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "fabric_grey", "rblok:fabric_grey", {
	description = "fabric grey",
	tiles = {"fabric_grey.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "drywallred", "rblok:drywallred", {
	description = "rblok_dry_wall _red",
	tiles = {"baked_clay_red.png", "baked_clay_white.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "drywallmarble", "rblok:drywallmarble", {
	description = "rblok_dry_wall_marble",
	tiles = {"drywallmarble.png", "baked_clay_white.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "drywallcgrey", "rblok:drywallcgrey", {
	description = "rblok_dry_wall_carpet grey",
	tiles = {"drywallcgrey.jpg", "baked_clay_white.png" },
	groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
	sounds = default.node_sound_stone_defaults(),
	})

stairsplus:register_all("rblok", "lightblock", "rblok:lightblock", {
		description = "rblok_lightblock",
		tiles = {"bsside.png",
	"bsside.png",
	"rlight.png",
	"rlight.png",
	"rlight.png",
	"rlight.png",
	},
		groups = {oddly_breakable_by_hand = 3, choppy=3},
		sounds = default.node_sound_glass_defaults(),
			--light_source = 10,
			light_source = default.LIGHT_MAX-1,
			use_texture_alpha = true,
			paramtype="light",
	})

  stairsplus:register_all("rblok", "lightblock1", "rblok:lightblock1", {
  		description = "rblok_lightblock1",
  		tiles = {"baked_clay_white.png",
  	"baked_clay_white.png",
  	"rlight1.png",
  	"rlight1.png",
  	"rlight1.png",
  	"rlight1.png",
  	},
  		groups = {oddly_breakable_by_hand = 3, choppy=3},
  		sounds = default.node_sound_glass_defaults(),
  			--light_source = 10,
  			light_source = default.LIGHT_MAX-1,
  			use_texture_alpha = true,
  			paramtype="light",
  	})

stairsplus:register_all("rblok", "applewood", "rblok:applewood", {
		description = "rblok_sprucewood",
		tiles = {"applewood.png"},
		groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
		sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "sprucewood", "rblok:sprucewood", {
		description = "rblok_sprucewood",
		tiles = {"sprucewood.png"},
		groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
		sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "birchwood", "rblok:birchwood", {
		description = "rblok_birchwood",
		tiles = {"birchwood.png"},
		groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
		sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "willowwood", "rblok:willowwood", {
		description = "rblok_willowwood",
		tiles = {"willowwood.png"},
		groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
		sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "wornwood", "rblok:wornwood", {
		description = "rblok_wornwood",
		tiles = {"wornwood256.png"},
		groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
		sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "floortile", "rblok:floortile", {
		description = "rblok_floortile",
		tiles = {"floortilegreen.png"},
		groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
		sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "floortilegold", "rblok:floortilegold", {
		description = "rblok_floortilegold",
		tiles = {"floortilegold.png"},
		groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
		sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "darkgrey", "rblok:darkgrey", {
		description = "rblok_darkgrey",
		tiles = {"darkgrey.png"},
		groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
		sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "bluewood", "rblok:bluewood", {
		description = "rblok_bluewood",
		tiles = {"bluewood.png"},
		groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
		sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "tile_color1", "rblok:tile_color1", {
		description = "rblok_tile_color1",
		tiles = {"tile_color1.png"},
		groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
		sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "tile_white", "rblok:tile_white", {
		description = "rblok_tile_white",
		tiles = {"tile_white.png"},
		groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
		sounds = default.node_sound_stone_defaults(),
	})

	stairsplus:register_all("rblok", "tile_white1", "rblok:tile_white1", {
		description = "rblok_tile_white1",
		tiles = {"tile_white1.png"},
		groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
		sounds = default.node_sound_stone_defaults(),
	})

  stairsplus:register_all("rblok", "darkgrey1", "rblok:darkgrey1", {
		description = "rblok_darkgrey1_block",
		tiles = {"dark_grey.png"},
		groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
		sounds = default.node_sound_stone_defaults(),
	})

  stairsplus:register_all("rblok", "tan2", "rblok:tan2", {
		description = "rblok_tan2_block",
		tiles = {"tan2.png"},
		groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
		sounds = default.node_sound_stone_defaults(),
	})

  stairsplus:register_all("rblok", "brown3", "rblok:brown3", {
    description = "rblok_brown3_block",
    tiles = {"brown3.png"},
    groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
    sounds = default.node_sound_stone_defaults(),
  })

  stairsplus:register_all("rblok", "tan1", "rblok:tan1", {
    description = "rblok_tan1_block",
    tiles = {"tan1.png"},
    groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
    sounds = default.node_sound_stone_defaults(),
  })

  stairsplus:register_all("rblok", "blueGrey1", "rblok:blueGrey1", {
    description = "rblok_blueGrey1_block",
    tiles = {"blueGrey1.png"},
    groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
    sounds = default.node_sound_stone_defaults(),
  })

  stairsplus:register_all("rblok", "brown1", "rblok:brown1", {
    description = "rblok_brown1_block",
    tiles = {"colorTest.png"},
    groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
    sounds = default.node_sound_stone_defaults(),
  })

  stairsplus:register_all("rblok", "brown2", "rblok:brown2", {
    description = "rblok_brown2_block",
    tiles = {"colorTest2.png"},
    groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
    sounds = default.node_sound_stone_defaults(),
  })



	end
	--stairsplus:register_alias_all("rblok", "sprucewood", "rblok", "rblok_sprucewood_")
