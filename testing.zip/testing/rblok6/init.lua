minetest.register_node("rblok6:cobbledark", {
description = "dark cobble",
tiles = {"cobbledark.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok6:cobblelight", {
description = "light cobble",
tiles = {"cobblelight.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok6:cobblemed", {
description = "medium cobble",
tiles = {"cobblemed.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = default.node_sound_stone_defaults(),
})




--stairsplus registration

if minetest.get_modpath("moreblocks") then

  stairsplus:register_all("rblok6", "cobbledark", "rblok6:cobbledark", {
  description = "dark cobble",
  tiles = {"cobbledark.png"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = default.node_sound_stone_defaults(),
  })
  
  stairsplus:register_all("rblok6", "cobblelight", "rblok6:cobblelight", {
  description = "light cobble",
  tiles = {"cobblelight.png"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = default.node_sound_stone_defaults(),
  })
  
  stairsplus:register_all("rblok6", "cobblemed", "rblok6:cobblemed", {
  description = "medium cobble",
  tiles = {"cobblemed.png"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = default.node_sound_stone_defaults(),
  })

end
