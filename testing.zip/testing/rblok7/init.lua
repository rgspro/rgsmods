minetest.register_node("rblok7:tree1", {
description = "tree1",
tiles = {"tree1.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok7:stone1", {
description = "stone1",
tiles = {"fabric_grey.png", "stone1.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok7:greygrey", {
description = "carpet_grey_drywall",
tiles = {"fabric_grey.png", "rgrey1.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok7:woodgrey", {
description = "woodgrey",
tiles = {"floorwood1a.jpg", "rgrey1.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})
minetest.register_node("rblok7:stonegrey", {
description = "stonegrey",
tiles = {"wallstone05.png", "rgrey1.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok7:rwoodnew", {
description = "rwoodnew",
tiles = {"rwoodnew.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok7:rmarblenew", {
description = "rmarblenew",
tiles = {"rmarblenew.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok7:stonewall1", {
description = "stonewall1",
tiles = {"stonewall1.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok7:rbrick02", {
description = "rbrick02",
tiles = {"rbrick02.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

--stairsplus registration

if minetest.get_modpath("moreblocks") then

stairsplus:register_all("rblok7", "rbrick02", "rblok7:rbrick02", {
  description = "rbrick02",
  tiles = {"rbrick02.png"},
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })

stairsplus:register_all("rblok7", "stonewall1", "rblok7:stonewall1", {
  description = "stonewall1",
  tiles = {"stonewall1.jpg"},
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })

stairsplus:register_all("rblok7", "rmarblenew", "rblok7:rmarblenew", {
  description = "rmarblenew",
  tiles = {"rmarblenew.jpg"},
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })

  stairsplus:register_all("rblok7", "rwoodnew", "rblok7:rwoodnew", {
  description = "rwoodnew",
  tiles = {"rwoodnew.jpg"},
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })
  
  stairsplus:register_all("rblok7", "greygrey", "rblok7:greygrey", {
  description = "greygrey",
  tiles = {"fabric_grey.png", "rgrey1.png"},
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })

 stairsplus:register_all("rblok7", "woodgrey", "rblok7:woodgrey", {
  description = "woodgrey",
  tiles = {"floorwood1a.jpg", "rgrey1.png"},
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })

stairsplus:register_all("rblok7", "stonegrey", "rblok7:stonegrey", {
  description = "stonegrey",
  tiles = {"wallstone05.png", "rgrey1.png"},
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })
  
  stairsplus:register_all("rblok7", "tree1", "rblok7:tree1", {
  description = "tree1",
  tiles = {"tree1.png"},
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })

end
