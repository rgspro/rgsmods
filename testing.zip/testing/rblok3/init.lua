minetest.register_node("rblok3:gran4", {
description = "granit4",
tiles = {"granit4.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = sound_glass,
})

minetest.register_node("rblok3:gran5", {
description = "granit5",
tiles = {"granit5.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = sound_glass,
})

minetest.register_node("rblok3:gran6", {
description = "granit6",
tiles = {"granit6.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = sound_glass,
})

minetest.register_node("rblok3:gran7", {
description = "granit7",
tiles = {"granit7.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = sound_glass,
})

minetest.register_node("rblok3:marble1", {
description = "marble1",
tiles = {"marble1.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = sound_glass,
})

minetest.register_node("rblok3:marble2", {
description = "marble2",
tiles = {"marble2.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = sound_glass,
})

minetest.register_node("rblok3:marble2", {
description = "marble2",
tiles = {"marble2.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = sound_glass,
})

minetest.register_node("rblok3:wood32", {
description = "wood32",
tiles = {"wood32.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = sound_glass,
})

minetest.register_node("rblok3:gran1", {
description = "granit1",
tiles = {"granit1.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = sound_glass,
})

minetest.register_node("rblok3:gran2", {
description = "granit2",
tiles = {"granit2.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = sound_glass,
})

minetest.register_node("rblok3:gran3", {
description = "granit3",
tiles = {"granit3.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = sound_glass,
})

minetest.register_node("rblok3:glassblk", {
description = "Tinted Glass",
drawtype = "glasslike_framed_optional",
tiles = {"rgs_black_glass.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = sound_glass,
use_texture_alpha = true,
})

minetest.register_node("rblok3:glassblk1", {
description = "Tinted Glass1",
drawtype = "glasslike_framed_optional",
tiles = {"rgs_black_glass1.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = sound_glass,
use_texture_alpha = true,
})

minetest.register_node("rblok3:glassblue", {
description = "Tinted Glass blue",
drawtype = "glasslike_framed_optional",
tiles = {"rgs_blue_glass.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = sound_glass,
use_texture_alpha = true,
})

minetest.register_node("rblok3:glassblue1", {
description = "Tinted Glass blue1",
drawtype = "glasslike_framed_optional",
tiles = {"rgs_blue_glass1.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = sound_glass,
use_texture_alpha = true,
})

minetest.register_node("rblok3:glasswhite0", {
description = "Tinted Glass white",
drawtype = "glasslike_framed_optional",
tiles = {"rgs_white_glass.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = sound_glass,
use_texture_alpha = true,
})

minetest.register_node("rblok3:glasswhite1", {
description = "Tinted Glass white1",
drawtype = "glasslike_framed_optional",
tiles = {"rgs_white_glass1.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = sound_glass,
use_texture_alpha = true,
})

minetest.register_node("rblok3:glasswhite3", {
description = "Tinted Glass white3",
drawtype = "glasslike_framed_optional",
tiles = {"rgs_white_glass3.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = sound_glass,
use_texture_alpha = true,
})

minetest.register_node("rblok3:bricks1", {
description = "red bricks1",
tiles = {"bricks1.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = sound_glass,
})

minetest.register_node("rblok3:redbrick", {
description = "red bricks",
tiles = {"redbrick.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = sound_glass,
})

--stairsplus registration

if minetest.get_modpath("moreblocks") then

  stairsplus:register_all("rblok3", "gran4", "rblok3:gran4", {
  description = "granit4",
  tiles = {"granit4.jpg"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = sound_glass,
  })
  
  stairsplus:register_all("rblok3", "gran5", "rblok3:gran5", {
  description = "granit5",
  tiles = {"granit5.jpg"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = sound_glass,
  })
  
  stairsplus:register_all("rblok3", "gran6", "rblok3:gran6", {
  description = "granit6",
  tiles = {"granit6.jpg"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = sound_glass,
  })
  
  stairsplus:register_all("rblok3", "gran7", "rblok3:gran7", {
  description = "granit7",
  tiles = {"granit7.jpg"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = sound_glass,
  })
  
  stairsplus:register_all("rblok3", "marble2", "rblok3:marble2", {
  description = "marble2",
  tiles = {"marble2.jpg"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = sound_glass,
  })
  
  stairsplus:register_all("rblok3", "wood32", "rblok3:wood32", {
  description = "wood32",
  tiles = {"wood32.jpg"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = sound_glass,
  })
  
  stairsplus:register_all("rblok3", "marble1", "rblok3:marble1", {
  description = "marble1",
  tiles = {"marble1.jpg"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = sound_glass,
  })
  
  stairsplus:register_all("rblok3", "gran1", "rblok3:gran1", {
  description = "granit1",
  tiles = {"granit1.jpg"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = sound_glass,
  })
  
  stairsplus:register_all("rblok3", "gran2", "rblok3:gran2", {
  description = "granit2",
  tiles = {"granit2.jpg"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = sound_glass,
  })
  
  stairsplus:register_all("rblok3", "gran3", "rblok3:gran3", {
  description = "granit3",
  tiles = {"granit3.jpg"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = sound_glass,
  })

stairsplus:register_all("rblok3", "bricks2", "rblok3:redbrick", {
  description = "red bricks",
  tiles = {"redbrick.png"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = sound_glass,
  })

stairsplus:register_all("rblok3", "bricks1", "rblok3:bricks1", {
  description = "red bricks1",
  tiles = {"bricks1.png"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = sound_glass,
  })

stairsplus:register_all("rblok3", "Tinted_Glass", "rblok3:glasswhite3", {
  description = "Tinted_Glass white3",
drawtype = "glasslike_framed_optional",
  tiles = {"rgs_white_glass3.png"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = sound_glass,
use_texture_alpha = true,
  })

stairsplus:register_all("rblok3", "Tinted_Glass", "rblok3:glasswhite1", {
  description = "Tinted_Glass white1",
drawtype = "glasslike_framed_optional",
  tiles = {"rgs_white_glass1.png"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = sound_glass,
use_texture_alpha = true,
  })

stairsplus:register_all("rblok3", "Tinted_Glass", "rblok3:glasswhite0", {
  description = "Tinted_Glass white",
drawtype = "glasslike_framed_optional",
  tiles = {"rgs_white_glass.png"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = sound_glass,
use_texture_alpha = true,
  })

  stairsplus:register_all("rblok3", "Tinted_Glass", "rblok3:glassblk", {
  description = "Tinted_Glass",
drawtype = "glasslike_framed_optional",
  tiles = {"rgs_black_glass.png"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = sound_glass,
use_texture_alpha = true,
  })

stairsplus:register_all("rblok3", "Tinted_Glass1", "rblok3:glassblk1", {
  description = "Tinted_Glass1",
drawtype = "glasslike_framed_optional",
  tiles = {"rgs_black_glass1.png"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = sound_glass,
use_texture_alpha = true,
  })

stairsplus:register_all("rblok3", "Tinted_Glass_blue", "rblok3:glassblue", {
  description = "Tinted_Glass_blue",
drawtype = "glasslike_framed_optional",
  tiles = {"rgs_blue_glass.png"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = sound_glass,
use_texture_alpha = true,
  })

stairsplus:register_all("rblok3", "Tinted_Glass_blue1", "rblok3:glassblue1", {
  description = "Tinted_Glass_blue1",
drawtype = "glasslike_framed_optional",
  tiles = {"rgs_blue_glass1.png"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = sound_glass,
use_texture_alpha = true,
  })

end
