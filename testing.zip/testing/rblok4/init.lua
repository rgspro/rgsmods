minetest.register_node("rblok4:wallpaper1", {
description = "wallpaper1",
tiles = {"wallpaper1.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok4:wallpaper2", {
description = "wallpaper2",
tiles = {"wallpaper2.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok4:wallpaper3", {
description = "wallpaper3",
tiles = {"wallpaper3.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok4:wallpaper4", {
description = "wallpaper4",
tiles = {"wallpaper4.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok4:wallpaper5", {
description = "wallpaper5",
tiles = {"wallpaper5.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok4:wallpaper6", {
description = "wallpaper6",
tiles = {"wallpaper6.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok4:wallpaper7", {
description = "wallpaper7",
tiles = {"wallpaper7.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok4:wallpaper8", {
description = "wallpaper8",
tiles = {"wallpaper8.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok4:wallpaper9", {
description = "wallpaper9",
tiles = {"wallpaper9.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok4:wallpaper10", {
description = "wallpaper10",
tiles = {"wallpaper10.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("rblok4:wallpaper7a", {
description = "wallpaper7a",
tiles = {"wallpaper7.jpg", "baked_clay_white.png"},   
paramtype = "light",
paramtype2 = "facedir",
groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
sounds = default.node_sound_stone_defaults(),
})
--stairsplus registration

if minetest.get_modpath("moreblocks") then

  stairsplus:register_all("rblok4", "wallpaper1", "rblok4:wallpaper1", {
  description = "wallpaper1",
  tiles = {"wallpaper1.jpg"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = default.node_sound_stone_defaults(),
  })
  
  stairsplus:register_all("rblok4", "wallpaper2", "rblok4:wallpaper2", {
  description = "wallpaper2",
  tiles = {"wallpaper2.jpg"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = default.node_sound_stone_defaults(),
  })

stairsplus:register_all("rblok4", "wallpaper3", "rblok4:wallpaper3", {
  description = "wallpaper3",
  tiles = {"wallpaper3.jpg"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = default.node_sound_stone_defaults(),
  })
  
  stairsplus:register_all("rblok4", "wallpaper4", "rblok4:wallpaper4", {
  description = "wallpaper4",
  tiles = {"wallpaper4.jpg"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = default.node_sound_stone_defaults(),
  })

stairsplus:register_all("rblok4", "wallpaper5", "rblok4:wallpaper5", {
  description = "wallpaper5",
  tiles = {"wallpaper5.jpg"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = default.node_sound_stone_defaults(),
  })
  
  stairsplus:register_all("rblok4", "wallpaper6", "rblok4:wallpaper6", {
  description = "wallpaper6",
  tiles = {"wallpaper6.jpg"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = default.node_sound_stone_defaults(),
  })
  
  stairsplus:register_all("rblok4", "wallpaper7", "rblok4:wallpaper7", {
  description = "wallpaper7",
  tiles = {"wallpaper7.jpg"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = default.node_sound_stone_defaults(),
  })

stairsplus:register_all("rblok4", "wallpaper8", "rblok4:wallpaper8", {
  description = "wallpaper8",
  tiles = {"wallpaper8.jpg"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = default.node_sound_stone_defaults(),
  })
  
  stairsplus:register_all("rblok4", "wallpaper9", "rblok4:wallpaper9", {
  description = "wallpaper9",
  tiles = {"wallpaper9.jpg"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = default.node_sound_stone_defaults(),
  })

stairsplus:register_all("rblok4", "wallpaper10", "rblok4:wallpaper10", {
  description = "wallpaper10",
  tiles = {"wallpaper10.jpg"},
  groups = {snappy = 2, cracky = 3, oddly_breakable_by_hand = 3},
  sounds = default.node_sound_stone_defaults(),
  })

end
