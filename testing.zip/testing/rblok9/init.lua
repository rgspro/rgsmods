minetest.register_node("rblok9:oldwood100", {
description = "oldwood",
tiles = {"oldwood100.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok9:oldwood102", {
description = "oldwood1",
tiles = {"oldwood102.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok9:oldwood103", {
description = "oldwood2",
tiles = {"oldwood103.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok9:cobble100", {
description = "cobble100",
tiles = {"cobble100.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok9:stonebrick100", {
description = "stonebrick100",
tiles = {"stonebrick100.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok9:stonebrick102", {
description = "stonebrick102",
tiles = {"stonebrick102.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok9:stonebrick103", {
description = "stonebrick103",
tiles = {"stonebrick103.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

--stairsplus registration

if minetest.get_modpath("moreblocks") then

stairsplus:register_all("rblok9", "oldwood100", "rblok9:oldwood100", {
  description = "oldwood",
  tiles = {"oldwood100.png"},
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })

stairsplus:register_all("rblok9", "oldwood102", "rblok9:oldwood102", {
  description = "oldwood2",
  tiles = {"oldwood102.png"},
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })

stairsplus:register_all("rblok9", "oldwood103", "rblok9:oldwood103", {
  description = "oldwood3",
  tiles = {"oldwood103.png"},
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })
  
  stairsplus:register_all("rblok9", "cobble100", "rblok9:cobble100", {
  description = "cobble100",
  tiles = {"cobble100.png"},
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })
  
  stairsplus:register_all("rblok9", "stonebrick100", "rblok9:stonebrick100", {
  description = "stonebrick100",
  tiles = {"stonebrick100.png"},
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })
  
  stairsplus:register_all("rblok9", "stonebrick102", "rblok9:stonebrick102", {
  description = "stonebrick102",
  tiles = {"stonebrick102.png"},
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })
  
  stairsplus:register_all("rblok9", "stonebrick103", "rblok9:stonebrick103", {
  description = "oldwood",
  tiles = {"stonebrick103.png"},
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })
end
