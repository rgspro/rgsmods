minetest.register_node("rblok2:concretebare", {
description = "concrete bare",
tiles = {"conc_strange.jpg"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok2:floortile01", {
description = "floortile01",
tiles = {"ft_broken02_c.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok2:floortile02", {
description = "floortile02",
tiles = {"ft_broken03_c.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok2:floordiag", {
description = "floordiag",
tiles = {"ft_diagonal01_c.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok2:gimpwood", {
description = "gimpwood",
tiles = {"gimpwood.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok2:path1a", {
description = "path1a",
tiles = {"path1a.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok2:redbricks2", {
description = "redbricks2",
tiles = {"redbricks2.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok2:wallstone05", {
description = "wallstone05",
tiles = {"wallstone05.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok2:woodpattern", {
description = "woodpattern",
tiles = {"woodpattern.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok2:ruffred", {
description = "ruffred",
tiles = {"ruffred.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("rblok2:teak", {
description = "teak",
tiles = {"teak.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("rblok2:greydrk", {
description = "greydrk",
tiles = {"greydrk.png"},
paramtype = "light",
paramtype2 = "facedir",
groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
sounds = default.node_sound_stone_defaults(),
})

--stairsplus registration

if minetest.get_modpath("moreblocks") then


  stairsplus:register_all("rblok2", "greydrk", "rblok2:greydrk", {
  description = "greydrk",
  tiles = {"greydrk.png"
  },
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })

  stairsplus:register_all("rblok2", "teak", "rblok2:teak", {
  description = "teak",
  tiles = {"teak.png"
  },
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })

  stairsplus:register_all("rblok2", "ruffred", "rblok2:ruffred", {
  description = "ruffred",
  tiles = {"ruffred.png"
  },
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })

  stairsplus:register_all("rblok2", "woodpattern", "rblok2:woodpattern", {
  description = "woodpattern",
  tiles = {"woodpattern.png"
  },
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })

  stairsplus:register_all("rblok2", "wallstone05", "rblok2:wallstone05", {
  description = "wallstone05",
  tiles = {"wallstone05.png"
  },
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })

  stairsplus:register_all("rblok2", "redbricks2", "rblok2:redbricks2", {
  description = "redbricks2",
  tiles = {"redbricks2.png"
  },
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })

  stairsplus:register_all("rblok2", "path1a", "rblok2:path1a", {
  description = "path1a",
  tiles = {"path1a.png"
  },
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })

  stairsplus:register_all("rblok2", "gimpwood", "rblok2:gimpwood", {
  description = "gimpwood",
  tiles = {"gimpwood.png"
  },
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })

  stairsplus:register_all("rblok2", "floordiag", "rblok2:floordiag", {
  description = "floordiag",
  tiles = {"ft_diagonal01_c.png"
  },
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })

  stairsplus:register_all("rblok2", "concretebare", "rblok2:concretebare", {
  description = "concrete bare",
  tiles = {"conc_strange.jpg"
  },
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })

  stairsplus:register_all("rblok2", "floortile01", "rblok2:floortile01", {
  description = "floortile01",
  tiles = {"ft_broken02_c.png"
  },
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })

  stairsplus:register_all("rblok2", "floortile02", "rblok2:floortile02", {
  description = "floortile02",
  tiles = {"ft_broken02_c.png"
  },
  groups = {wood=2, oddly_breakable_by_hand = 3, choppy=3},
  sounds = default.node_sound_stone_defaults(),
  })


end
